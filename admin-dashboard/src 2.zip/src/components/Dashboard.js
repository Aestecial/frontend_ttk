import React from 'react';
import '../styles/Dashboard.css';

function Dashboard() {
  return (
    <div className="dashboard">
      <h2>Добро пожаловать!</h2>
    </div>
  );
}

export default Dashboard;